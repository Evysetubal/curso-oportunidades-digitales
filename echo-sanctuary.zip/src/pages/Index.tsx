import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Star,
  ArrowRight,
  Check,
  X,
  Users,
  MessageCircle,
  Video,
  Shield,
  TrendingUp,
  Zap,
  Globe,
  DollarSign,
  Target,
  Award,
  BookOpen,
  Lightbulb,
  Heart,
  Clock,
} from "lucide-react";

const Index = () => {
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);

  const courseModules = [
    {
      icon: <Globe className="w-6 h-6" />,
      title: "Ventas Online & E-commerce",
      description: "Aprende a vender cursos, productos físicos y digitales",
      color: "from-blue-500 to-purple-600",
    },
    {
      icon: <TrendingUp className="w-6 h-6" />,
      title: "Marketing de Afiliados",
      description: "Genera ingresos promocionando productos de terceros",
      color: "from-purple-500 to-pink-600",
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Colaboraciones con Marcas",
      description: "Monetiza tu audiencia con patrocinios y partnerships",
      color: "from-pink-500 to-orange-600",
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "Automatización de Canales",
      description: "YouTube, TikTok, Facebook en piloto automático",
      color: "from-orange-500 to-yellow-600",
    },
    {
      icon: <DollarSign className="w-6 h-6" />,
      title: "Dropshipping & Dropservicing",
      description: "Negocios sin inventario ni inversión inicial",
      color: "from-yellow-500 to-green-600",
    },
    {
      icon: <Target className="w-6 h-6" />,
      title: "Servicios de VA & IA",
      description:
        "Asistencia virtual y automatización con inteligencia artificial",
      color: "from-green-500 to-blue-600",
    },
  ];

  const credentials = [
    "2 Masters en E-commerce y Emprendimiento Digital",
    "MBA en Leadership",
    "Más de 10 años en Marketing Digital",
    "60+ proyectos exitosos",
    "Hasta 500k€ generados para clientes",
    "4 idiomas dominados",
    "Participación en masterminds europeos",
  ];

  const perfectFor = [
    "Personas cansadas de su trabajo actual",
    "Quienes quieren escapar del tráfico diario",
    "Profesionales con techo salarial limitado",
    "Trabajadores de +40 horas que no llegan a fin de mes",
    "Personas con ganas de cambio y crecimiento",
    "Emprendedores que quieren empezar de cero",
  ];

  const notFor = [
    "Personas perezosas que no quieren trabajar",
    "Quienes buscan soluciones mágicas",
    "Personas sin ganas de tomar acción",
    "Quienes ponen excusas para todo",
    "Buscadores de esquemas para hacerse ricos rápido",
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-purple-600 via-blue-600 to-green-500">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="container mx-auto px-4 py-20 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center text-white max-w-4xl mx-auto"
          >
            <Badge className="bg-white/20 text-white border-white/30 mb-6 text-sm px-4 py-2">
              ✨ Curso Completo de Emprendimiento Digital
            </Badge>

            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Descubre las{" "}
              <span className="text-yellow-300">Infinitas Oportunidades</span>{" "}
              del Mundo Digital
            </h1>

            <p className="text-xl md:text-2xl mb-8 opacity-90 leading-relaxed">
              Transforma tu vida financiera aprendiendo los secretos del
              emprendimiento digital que han ayudado a generar{" "}
              <strong className="text-yellow-300">más de 500k€</strong> a mis
              clientes
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <Button
                size="lg"
                className="bg-yellow-400 hover:bg-yellow-300 text-black font-bold px-8 py-4 text-lg shadow-2xl"
              >
                Acceder al Curso Ahora <ArrowRight className="ml-2 w-5 h-5" />
              </Button>

              <button
                onClick={() => setIsVideoPlaying(true)}
                className="flex items-center gap-2 text-white hover:text-yellow-300 transition-colors"
              >
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                  <Video className="w-6 h-6" />
                </div>
                Ver Video Presentación
              </button>
            </div>

            <div className="flex flex-wrap justify-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-green-300" />
                <span>7 días de garantía</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-300" />
                <span>Comunidad WhatsApp</span>
              </div>
              <div className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5 text-purple-300" />
                <span>Llamadas mensuales</span>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Floating elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-yellow-400/20 rounded-full blur-xl"></div>
        <div className="absolute bottom-20 right-10 w-32 h-32 bg-pink-400/20 rounded-full blur-xl"></div>
        <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-blue-400/20 rounded-full blur-xl"></div>
      </section>

      {/* Problem Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
              ¿Estás Cansado de la Vida Tradicional?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Millones de personas están atrapadas en empleos que no les
              satisfacen, con horarios inflexibles y salarios limitados.{" "}
              <strong>Es hora de cambiar las reglas del juego.</strong>
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              <div className="bg-red-50 border-l-4 border-red-400 p-6 rounded-r-lg">
                <h3 className="text-xl font-semibold text-red-800 mb-3">
                  La Realidad Tradicional:
                </h3>
                <ul className="space-y-2 text-red-700">
                  <li className="flex items-center gap-3">
                    <X className="w-5 h-5 text-red-500" />
                    Horarios de 40+ horas semanales
                  </li>
                  <li className="flex items-center gap-3">
                    <X className="w-5 h-5 text-red-500" />
                    Techo salarial limitado
                  </li>
                  <li className="flex items-center gap-3">
                    <X className="w-5 h-5 text-red-500" />
                    Tiempo perdido en tráfico
                  </li>
                  <li className="flex items-center gap-3">
                    <X className="w-5 h-5 text-red-500" />
                    Dependencia de un solo ingreso
                  </li>
                  <li className="flex items-center gap-3">
                    <X className="w-5 h-5 text-red-500" />
                    Sin flexibilidad ni libertad
                  </li>
                </ul>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              <div className="bg-green-50 border-l-4 border-green-400 p-6 rounded-r-lg">
                <h3 className="text-xl font-semibold text-green-800 mb-3">
                  El Futuro Digital:
                </h3>
                <ul className="space-y-2 text-green-700">
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    Trabajo desde cualquier lugar
                  </li>
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    Ingresos escalables sin límites
                  </li>
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    Horarios completamente flexibles
                  </li>
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    Múltiples fuentes de ingresos
                  </li>
                  <li className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    Libertad financiera real
                  </li>
                </ul>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Course Modules */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
              Lo Que Aprenderás en el Curso
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              6 módulos completos que te enseñarán todas las oportunidades del
              mundo digital y cómo aprovecharlas
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courseModules.map((module, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-2xl transition-all duration-300 group cursor-pointer">
                  <CardContent className="p-6">
                    <div
                      className={`w-12 h-12 rounded-lg bg-gradient-to-r ${module.color} flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform`}
                    >
                      {module.icon}
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-3">
                      {module.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      {module.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Instructor Section */}
      <section className="py-20 bg-gradient-to-br from-purple-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Badge className="bg-purple-100 text-purple-700 mb-4">
                Tu Instructora
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Evelyn Setubal
              </h2>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Experta en marketing digital con más de 10 años de experiencia
                ayudando a empresas y emprendedores a generar resultados
                extraordinarios en el mundo digital.
              </p>

              <div className="grid sm:grid-cols-2 gap-4 mb-8">
                {credentials.map((credential, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="flex items-center gap-3"
                  >
                    <Award className="w-5 h-5 text-purple-600 flex-shrink-0" />
                    <span className="text-gray-700">{credential}</span>
                  </motion.div>
                ))}
              </div>

              <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6 rounded-lg">
                <h3 className="text-lg font-semibold mb-2">
                  Resultado Comprobado:
                </h3>
                <p className="text-purple-100">
                  "He ayudado a mis clientes a generar hasta{" "}
                  <strong className="text-yellow-300">500k€</strong> aplicando
                  las estrategias que enseño en este curso."
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <div className="w-80 h-80 mx-auto bg-gradient-to-br from-purple-400 to-blue-500 rounded-full flex items-center justify-center mb-6">
                <div className="w-72 h-72 bg-white rounded-full flex items-center justify-center">
                  <span className="text-6xl">👩‍💼</span>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "Mi misión es abrir tu mente a las infinitas posibilidades del
                mundo digital y ayudarte a encontrar tu propio camino hacia la
                libertad financiera."
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Target Audience */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
              ¿Es Este Curso Para Ti?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Sé completamente honesta contigo: este curso funciona, pero no es
              para todo el mundo
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Card className="h-full bg-green-50 border-green-200">
                <CardContent className="p-8">
                  <div className="flex items-center gap-3 mb-6">
                    <Heart className="w-8 h-8 text-green-600" />
                    <h3 className="text-2xl font-bold text-green-800">
                      ES PERFECTO PARA TI SI:
                    </h3>
                  </div>
                  <ul className="space-y-4">
                    {perfectFor.map((item, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <Check className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                        <span className="text-green-700 font-medium">
                          {item}
                        </span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Card className="h-full bg-red-50 border-red-200">
                <CardContent className="p-8">
                  <div className="flex items-center gap-3 mb-6">
                    <X className="w-8 h-8 text-red-600" />
                    <h3 className="text-2xl font-bold text-red-800">
                      NO ES PARA TI SI:
                    </h3>
                  </div>
                  <ul className="space-y-4">
                    {notFor.map((item, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <X className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
                        <span className="text-red-700 font-medium">{item}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Community & Support */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
              No Estarás Solo en Este Viaje
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Además del curso completo, tendrás acceso a una comunidad activa y
              soporte directo
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Card className="text-center h-full">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <MessageCircle className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">
                    Comunidad WhatsApp
                  </h3>
                  <p className="text-gray-600">
                    Únete a una comunidad exclusiva de estudiantes donde podrás
                    hacer preguntas, compartir experiencias y networking.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
            >
              <Card className="text-center h-full">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Video className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">
                    Llamadas Mensuales
                  </h3>
                  <p className="text-gray-600">
                    Sesiones mensuales en vivo conmigo para resolver dudas,
                    analizar casos y mantenerte motivado en tu progreso.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <Card className="text-center h-full">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Lightbulb className="w-8 h-8 text-purple-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">
                    Contenido Actualizado
                  </h3>
                  <p className="text-gray-600">
                    El mundo digital cambia constantemente. Recibirás
                    actualizaciones y nuevas estrategias de forma regular.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Pricing & CTA */}
      <section className="py-20 bg-gradient-to-br from-purple-600 via-blue-600 to-green-500">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
              Invierte en tu Futuro Digital Hoy
            </h2>
            <p className="text-xl text-white/90 mb-12">
              El precio de este curso es una fracción de lo que pagarías por una
              consultoría privada, pero con el mismo valor transformador
            </p>

            <Card className="max-w-2xl mx-auto mb-12">
              <CardContent className="p-8 text-center">
                <Badge className="bg-yellow-100 text-yellow-800 mb-4 text-sm">
                  🔥 Precio de Lanzamiento
                </Badge>

                <div className="mb-6">
                  <span className="text-4xl md:text-6xl font-bold text-gray-900">
                    497€
                  </span>
                  <div className="text-gray-500 line-through text-xl">997€</div>
                </div>

                <div className="space-y-3 mb-8 text-left">
                  <div className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span>6 módulos completos del curso</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span>Acceso a la comunidad WhatsApp</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span>Llamadas mensuales de seguimiento</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span>Acceso de por vida al contenido</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span>Actualizaciones gratuitas</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Shield className="w-5 h-5 text-green-500" />
                    <span className="font-semibold">Garantía de 7 días</span>
                  </div>
                </div>

                <Button
                  size="lg"
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-bold py-4 text-lg shadow-2xl"
                >
                  Acceder al Curso Completo Ahora
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>

                <div className="flex items-center justify-center gap-2 mt-4 text-sm text-gray-500">
                  <Clock className="w-4 h-4" />
                  <span>Precio especial disponible por tiempo limitado</span>
                </div>
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-3 gap-6 text-white">
              <div className="text-center">
                <Shield className="w-8 h-8 mx-auto mb-2 text-green-300" />
                <h3 className="font-semibold mb-1">Garantía Total</h3>
                <p className="text-sm opacity-90">
                  7 días para probarlo sin riesgo
                </p>
              </div>
              <div className="text-center">
                <BookOpen className="w-8 h-8 mx-auto mb-2 text-blue-300" />
                <h3 className="font-semibold mb-1">Acceso Inmediato</h3>
                <p className="text-sm opacity-90">
                  Empieza hoy mismo tu transformación
                </p>
              </div>
              <div className="text-center">
                <Users className="w-8 h-8 mx-auto mb-2 text-purple-300" />
                <h3 className="font-semibold mb-1">Comunidad Activa</h3>
                <p className="text-sm opacity-90">
                  Networking con otros emprendedores
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 bg-gray-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-2xl md:text-4xl font-bold mb-6">
              ¿Estás Listo para Cambiar tu Vida?
            </h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              El momento perfecto no existe. El momento es ahora. Da el primer
              paso hacia tu libertad financiera y personal.
            </p>
            <Button
              size="lg"
              className="bg-yellow-400 hover:bg-yellow-300 text-black font-bold px-8 py-4 text-lg"
            >
              Sí, Quiero Transformar Mi Vida
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-gray-300 py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="mb-2">
            © 2024 Evelyn Setubal - Experta en Emprendimiento Digital
          </p>
          <p className="text-sm">
            Transformando vidas a través del marketing digital desde 2014
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
